package examjavaweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamJavaWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
