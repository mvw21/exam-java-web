package examjavaweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamJavaWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamJavaWebApplication.class, args);
    }

}
